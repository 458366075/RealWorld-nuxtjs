import Vue from 'vue'
import Router from 'vue-router'
import { normalizeURL, decode } from 'ufo'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _b1633f56 = () => interopDefault(import('../pages/settings.vue' /* webpackChunkName: "pages/settings" */))
const _2b560722 = () => interopDefault(import('../pages/article/_slug.vue' /* webpackChunkName: "pages/article/_slug" */))
const _b6b03dcc = () => interopDefault(import('../pages/editor/_slug.vue' /* webpackChunkName: "pages/editor/_slug" */))
const _b75d42e6 = () => interopDefault(import('../pages/profile/_username.vue' /* webpackChunkName: "pages/profile/_username" */))
const _7749264a = () => interopDefault(import('../pages/profile/_username/_favorites.vue' /* webpackChunkName: "pages/profile/_username/_favorites" */))
const _ce9664e0 = () => interopDefault(import('../pages/index.vue' /* webpackChunkName: "pages/index" */))
const _d6790cc8 = () => interopDefault(import('../pages/_login.vue' /* webpackChunkName: "pages/_login" */))

const emptyFn = () => {}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: '/',
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/settings",
    component: _b1633f56,
    name: "settings"
  }, {
    path: "/article/:slug?",
    component: _2b560722,
    name: "article-slug"
  }, {
    path: "/editor/:slug?",
    component: _b6b03dcc,
    name: "editor-slug"
  }, {
    path: "/profile/:username?",
    component: _b75d42e6,
    name: "profile-username",
    children: [{
      path: ":favorites?",
      component: _7749264a,
      name: "profile-username-favorites"
    }]
  }, {
    path: "/",
    component: _ce9664e0,
    name: "index"
  }, {
    path: "/:login",
    component: _d6790cc8,
    name: "login"
  }],

  fallback: false
}

export function createRouter (ssrContext, config) {
  const base = (config._app && config._app.basePath) || routerOptions.base
  const router = new Router({ ...routerOptions, base  })

  // TODO: remove in Nuxt 3
  const originalPush = router.push
  router.push = function push (location, onComplete = emptyFn, onAbort) {
    return originalPush.call(this, location, onComplete, onAbort)
  }

  const resolve = router.resolve.bind(router)
  router.resolve = (to, current, append) => {
    if (typeof to === 'string') {
      to = normalizeURL(to)
    }
    return resolve(to, current, append)
  }

  return router
}
